from fpdf import FPDF
import re

class PDF(FPDF):
    def footer(self):
        # Position at 1.5 cm from bottom
        self.set_y(-15)
        # Helvetica italic 8
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(128, 128, 128)
        # Page number
        self.cell(0, 10, f"Page {self.page_no()}", align="C")

def sanitize_text(text: str) -> str:
    """Replaces common problematic unicode characters with latin-1 equivalents before PDF generation."""
    replacements = {
        '–': '-', '—': '-', '“': '"', '”': '"', '‘': "'", '’': "'",
        '…': '...', '\u200b': '', '\u200e': '', '\u200f': ''
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.encode('latin-1', 'replace').decode('latin-1')

import textwrap

def split_long_words(text: str, max_chars: int = 80) -> str:
    """Splits extremely long words (like URLs) so FPDF doesn't crash on word-wrap."""
    words = text.split()
    wrapped_words = []
    for word in words:
        if len(word) > max_chars:
            wrapped_words.append(" ".join(textwrap.wrap(word, max_chars, break_long_words=True)))
        else:
            wrapped_words.append(word)
    return " ".join(wrapped_words)

def markdown_to_pdf(markdown_text: str) -> bytes:
    """
    Parses simple Markdown and renders it to a PDF using FPDF to fulfill the Flask stack requirement.
    """
    markdown_text = sanitize_text(markdown_text)
    pdf = PDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)
    
    # Parse Markdown lines
    lines = markdown_text.split('\n')
    for line in lines:
        line = line.strip()
        if not line:
            pdf.ln(4)
            continue
            
        # Clean basic bold/italic markers to plain text for FPDF parsing
        clean_line = line.replace('**', '').replace('__', '').replace('*', '')
        # Prevent FPDF crash on incredibly long URLs or unbroken strings
        clean_line = split_long_words(clean_line)
        
        try:
            if clean_line.startswith('# '):
                pdf.set_font("Helvetica", "B", 20)
                pdf.set_text_color(44, 62, 80)
                pdf.multi_cell(0, 10, clean_line[2:].strip())
                pdf.ln(5)
            elif clean_line.startswith('## '):
                pdf.set_font("Helvetica", "B", 16)
                pdf.set_text_color(41, 128, 185)
                pdf.multi_cell(0, 8, clean_line[3:].strip())
                pdf.ln(2)
            elif clean_line.startswith('### '):
                pdf.set_font("Helvetica", "B", 13)
                pdf.set_text_color(52, 73, 94)
                pdf.multi_cell(0, 7, clean_line[4:].strip())
                pdf.ln(1)
            elif clean_line.startswith('- '):
                pdf.set_font("Helvetica", "", 11)
                pdf.set_text_color(51, 51, 51)
                pdf.multi_cell(0, 6, ">  " + clean_line[2:].strip())
            else:
                if re.match(r'^\d+\.\s', clean_line):
                    pdf.set_font("Helvetica", "", 11)
                    pdf.set_text_color(51, 51, 51)
                    pdf.multi_cell(0, 6, clean_line)
                else:
                    pdf.set_font("Helvetica", "", 11)
                    pdf.set_text_color(51, 51, 51)
                    pdf.multi_cell(0, 6, clean_line)
        except Exception as e:
            # Fallback for any other obscure FPDF text rendering bugs
            print(f"Skipping line due to FPDF error: {e}")
            
    # Return as bytes
    pdf_bytearray = pdf.output(dest='S')
    if isinstance(pdf_bytearray, bytearray):
        return bytes(pdf_bytearray)
    return pdf_bytearray
