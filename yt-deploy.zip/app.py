from flask import Flask, render_template, request
import os
from dotenv import load_dotenv

from extractor import process_youtube_url, extract_video_id
from summarizer import generate_article
from pdf_generator import markdown_to_pdf

load_dotenv()

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        try:
            url = request.form.get("url")
            if not url:
                return "Error: No URL provided"
            
            # Step 1: Extract (with Fallback built-in)
            extraction_data = process_youtube_url(url)
            
            # Step 2: Summarize using environment API Key
            api_key = os.environ.get("GEMINI_API_KEY")
            article_md = generate_article(extraction_data, api_key=api_key)
            
            # Step 3: PDF Generation
            if not os.path.exists("static"):
                os.makedirs("static")
                
            pdf_bytes = markdown_to_pdf(article_md)
            
            # Save the static PDF exactly like the original youtube-to-pdf layout
            with open("static/output.pdf", "wb") as f:
                f.write(pdf_bytes)

            return render_template("result.html", summary=article_md)
            
        except Exception as e:
            return render_template("index.html", error=str(e))

    return render_template("index.html")

if __name__ == '__main__':
    app.run(debug=True, port=5000)
