import os
import google.generativeai as genai

def generate_article(extraction_data: dict, api_key: str = None) -> str:
    """
    Takes extraction data (either a transcript or fallback metadata) and uses Google Gemini to generate an 
    insightful, well-structured article formatted in Markdown.
    """
    key = api_key or os.environ.get("GEMINI_API_KEY")
    if not key:
        raise ValueError("GEMINI_API_KEY is not set. Please provide it in the input or .env file.")

    genai.configure(api_key=key)

    # Using gemini-2.5-flash as the api key only supports 2.0+ models
    model = genai.GenerativeModel('gemini-2.5-flash')

    sys_prompt = """
    You are an expert content writer and analyst. Your objective is to transform the provided information about a YouTube video into a highly engaging, insightful, and well-structured article formatted in Markdown.
    
    Please include:
    1. A catchy **Title** (Start with a single # heading).
    2. An **Introduction** summarizing the core premise.
    3. **Key Takeaways** (use bullet points).
    4. **Detailed Sections** covering the main arguments or topics discussed. Use informative ## or ### headings.
    5. A **Conclusion** summarizing the overall impact or final thoughts.
    
    Ensure the tone is professional, insightful, and accessible. Do not reference the fact that you are an AI. Write it as a standalone, polished piece.
    """

    if extraction_data["type"] == "transcript":
        content_prompt = f"Here is the raw transcript of the video:\n\n{extraction_data['content']}"
    elif extraction_data["type"] == "fallback":
        meta = extraction_data["content"]
        content_prompt = f"The transcript for this video was unavailable. However, here is the Video Title and Description metadata. Please generate a speculative and insightful summary article based on this context:\n\nTitle: {meta['title']}\n\nDescription: {meta['description']}"
    else:
        raise ValueError("Invalid extraction data type.")
        
    full_prompt = sys_prompt + "\n\n" + content_prompt

    try:
        response = model.generate_content(full_prompt)
        return response.text
    except Exception as e:
        raise Exception(f"Failed to generate article using Gemini: {str(e)}")
