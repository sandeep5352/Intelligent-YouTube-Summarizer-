import re
import requests
from bs4 import BeautifulSoup
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api.formatters import TextFormatter

def extract_video_id(url: str) -> str:
    """Extracts the YouTube video ID from a given URL."""
    pattern = r'(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})'
    match = re.search(pattern, url)
    if match:
        return match.group(1)
    else:
        raise ValueError("Invalid YouTube URL. Please provide a valid video link.")

def get_transcript(video_id: str):
    """Fetches the transcript for a given YouTube video ID."""
    transcript_list = YouTubeTranscriptApi.get_transcript(video_id)
    formatter = TextFormatter()
    return formatter.format_transcript(transcript_list)

def get_fallback_metadata(url: str):
    """Fetches video title and description as a fallback when transcripts are unavailable."""
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    
    soup = BeautifulSoup(response.text, "html.parser")
    
    title_tag = soup.find("meta", property="og:title")
    title = title_tag["content"] if title_tag else soup.title.string if soup.title else "Unknown Title"
    
    desc_tag = soup.find("meta", property="og:description")
    description = desc_tag["content"] if desc_tag else "No description available."
    
    return {"title": title, "description": description}

def process_youtube_url(url: str) -> dict:
    """
    Attempts to get the transcript. 
    If unavailable, implements a fallback mechanism using metadata.
    Returns: {"type": "transcript", "content": "..."} OR {"type": "fallback", "content": {"title": "...", "description": "..."}}
    """
    video_id = extract_video_id(url)
    try:
        # 1. Primary method: Extract transcript
        text = get_transcript(video_id)
        return {"type": "transcript", "content": text}
    except Exception as e:
        print(f"Transcript extraction failed for {video_id}: {str(e)}. Initiating fallback...")
        # 2. Fallback Mechanism: Fetch Metadata
        try:
            metadata = get_fallback_metadata(url)
            return {"type": "fallback", "content": metadata}
        except Exception as fallback_err:
            raise Exception(f"Both transcript and fallback extraction failed. Error: {str(fallback_err)}")
